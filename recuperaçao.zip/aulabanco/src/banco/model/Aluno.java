package banco.model;

import java.io.Serializable;

public class Aluno implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String nomealuno;
	private String email;
	private String endereco;
	private String bairro;
	private String nascimento;
	public String getNomealuno() {
		return nomealuno;
	}
	public void setNomealuno(String nomealuno) {
		this.nomealuno = nomealuno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getBairro() {
		return bairro;
	}
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	public String getNascimento() {
		return nascimento;
	}
	public void setNascimento(String nascimento) {
		this.nascimento = nascimento;
	}
	@Override
	public String toString() {
		return "Aluno [nomealuno=" + nomealuno + ", email=" + email + ", endereco=" + endereco + ", bairro=" + bairro
				+ ", nascimento=" + nascimento + "]";
	}
	
}
