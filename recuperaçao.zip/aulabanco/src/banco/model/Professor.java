package banco.model;

import java.io.Serializable;

public class Professor implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String nome;
	private String disciplina;
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDisciplina() {
		return disciplina;
	}
	public void setDisciplina(String disciplina) {
		this.disciplina = disciplina;
	}
	@Override
	public String toString() {
		return "Professor [nome=" + nome + ", disciplina=" + disciplina + "]";
	}
	

}
