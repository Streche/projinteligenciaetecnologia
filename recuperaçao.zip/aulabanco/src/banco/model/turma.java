package banco.model;

import java.io.Serializable;

public class turma implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private String titulo;
	private String ano;
	private String periodo;
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getAno() {
		return ano;
	}
	public void setAno(String ano) {
		this.ano = ano;
	}
	public String getPeriodo() {
		return periodo;
	}
	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}
	@Override
	public String toString() {
		return "turma [titulo=" + titulo + ", ano=" + ano + ", periodo=" + periodo + "]";
	}
	
	
}
